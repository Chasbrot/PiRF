/**
 * Copyright (c) 2010-2021 Contributors to the openHAB project
 *
 * See the NOTICE file(s) distributed with this work for additional
 * information.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0
 *
 * SPDX-License-Identifier: EPL-2.0
 */
package org.openhab.binding.pirf.internal;

import org.eclipse.jdt.annotation.NonNullByDefault;
import org.eclipse.jdt.annotation.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.pi4j.io.gpio.GpioController;
import com.pi4j.io.gpio.GpioFactory;
import com.pi4j.io.gpio.GpioPinDigitalOutput;
import com.pi4j.io.gpio.Pin;
import com.pi4j.io.gpio.PinPullResistance;
import com.pi4j.io.gpio.PinState;
import com.pi4j.io.gpio.RaspiPin;
import com.pi4j.wiringpi.Gpio;

/*-----------------------------------------------------------
    

    -----------------------------------------------------------*/
/**
 * Library for controlling switching 433 Mhz remote controlled sockets from Unitec with pseudo rolling code
 * 
 * by Till Nenz
 * https://github.com/tnn85/UnitecRCSwitch
 * 
 * Ported to Java by
 * 
 * @author Michael Selinger - Initial contribution
 *
 */
@NonNullByDefault
public class PiRFUnitec {

    private static final Integer UNITEC_PULSE_LENGTH = 380; // Min. pulse lenght in [µs]
    private static final Integer UNITEC_NUM_SEND_REPETIONS = 4;
    public static final Integer UNITEC_NUM_ROLLINGCODES = 4;

    private final Logger logger = LoggerFactory.getLogger(PiRFUnitec.class);

    private int rollindex = 0;

    private int tx_pin = -1;

    private @Nullable GpioPinDigitalOutput transmitterPin;

    private long btnCodes[] = {};

    public PiRFUnitec() {
        this.tx_pin = -1;
    }

    /**
     * Create pulse on digital out pin
     *
     * @param numLowPulses Number of high pulse in multiples of UNITEC_PULSE_LENGTH
     * @param numLowPulses Number of low pulse in multiples of UNITEC_PULSE_LENGTH
     */
    @SuppressWarnings("all")
    private void pulse(int numHighPulses, int numLowPulses) {
        this.transmitterPin.high();
        Gpio.delayMicroseconds(UNITEC_PULSE_LENGTH * numHighPulses);
        this.transmitterPin.low();
        Gpio.delayMicroseconds(UNITEC_PULSE_LENGTH * numLowPulses);
    }

    /**
     * Send code
     *
     * @param code Code as long value (24 Bit)
     */
    @SuppressWarnings("all")
    private void send(long code) {
        int i, j, k;

        // Convert long to binary string
        String bits = Long.toBinaryString(code);

        // Fill binary string to 24 bit
        StringBuilder sb = new StringBuilder();
        for (int l = 0; l < (24 - bits.length()); l++) {
            sb.append("0");
        }
        sb.append(bits);
        bits = sb.toString();

        // Convert to boolean array for faster access times, to be save
        boolean[] d = new boolean[24];
        for (int l = 0; l < bits.length(); l++) {
            d[l] = (bits.charAt(l) == '1');
        }

        for (k = 0; k < 2; k++) { // Send 4 repetions (4 x 24 Bits) with short sync pause and another 4 repetions ( 4 x
                                  // 24 Bits) with long sync pause
            for (j = 0; j < UNITEC_NUM_SEND_REPETIONS; j++) {
                if (k == 0) {
                    pulse(1, 6);
                } else {
                    pulse(8, 19);
                }
                for (i = 0; i < 24; i++) {
                    if (d[i]) {
                        pulse(3, 1);
                    } else {
                        pulse(1, 3);
                    }
                }
            }
        }
        this.transmitterPin.low();
    }

    public void switchUnitec() {
        if (rollindex > 3) {
            rollindex = 0;
        }
        send(btnCodes[rollindex++]);
    }

    public void setBtnCodes(long[] c) {
        this.btnCodes = c;
    }

    public int getTxPin() {
        return this.tx_pin;
    }

    @SuppressWarnings("all")
    public boolean setTxPin(int pin) {
        final GpioController gpio = GpioFactory.getInstance();
        Pin p = RaspiPin.getPinByAddress(pin);
        if (gpio.getProvisionedPin(p) == null) {
            this.transmitterPin = gpio.provisionDigitalOutputPin(p);
        } else {
            this.transmitterPin = (GpioPinDigitalOutput) gpio.getProvisionedPin(p);
        }
        if (this.transmitterPin == null) {
            logger.warn("PiRF Unitec: Cannot provision Pin");
            return false;
        }
        this.transmitterPin.setShutdownOptions(true, PinState.LOW, PinPullResistance.OFF);
        tx_pin = pin;
        return true;
    }
}

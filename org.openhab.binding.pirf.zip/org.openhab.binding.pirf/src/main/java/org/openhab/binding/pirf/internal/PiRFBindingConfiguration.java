/**
 * Copyright (c) 2010-2021 Contributors to the openHAB project
 *
 * See the NOTICE file(s) distributed with this work for additional
 * information.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0
 *
 * SPDX-License-Identifier: EPL-2.0
 */
package org.openhab.binding.pirf.internal;

import org.eclipse.jdt.annotation.NonNullByDefault;

/**
 * The {@link PiRFBindingConfiguration} class contains fields mapping thing configuration parameters.
 *
 * @author Michael Selinger - Initial contribution
 */
@NonNullByDefault
public class PiRFBindingConfiguration {

    /**
     * Configuration parameter for RF Switches
     */
    public Integer oncode = -1;
    public Integer offcode = -1;

    /**
     * Configuration parameter for RF Modulation
     */
    public Integer protocol = -1;
    public Integer pulslength = -1;
}

/**
 * Copyright (c) 2010-2021 Contributors to the openHAB project
 *
 * See the NOTICE file(s) distributed with this work for additional
 * information.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0
 *
 * SPDX-License-Identifier: EPL-2.0
 */
package org.openhab.binding.pirf.internal;

import org.eclipse.jdt.annotation.NonNullByDefault;
import org.openhab.core.thing.ThingTypeUID;

/**
 * The {@link PiRFBindingConstants} class defines common constants, which are
 * used across the whole binding.
 *
 * @author Chasbrot - Initial contribution
 */
@NonNullByDefault
public class PiRFBindingConstants {

    private PiRFBindingConstants() {
        throw new IllegalStateException("Utility class");
    }

    private static final String BINDING_ID = "pirf";

    // List of all Thing Type UIDs
    public static final ThingTypeUID THING_TYPE_GENERICSWITCH = new ThingTypeUID(BINDING_ID, "genericswitch");
    public static final ThingTypeUID THING_TYPE_GROUPSWITCH = new ThingTypeUID(BINDING_ID, "groupswitch");
    public static final ThingTypeUID THING_TYPE_UNITECSWITCH = new ThingTypeUID(BINDING_ID, "unitecswitch");

    // List of all Channel Types
    public static final String CHANNEL_TYPE_SWITCH = "switch";
    public static final String CHANNEL_TYPE_GROUP = "group";
    public static final String CHANNEL_TYPE_UNITEC = "unitec";

    // List of all Channel IDs
    // public static final String CHANNEL_UNITECA = "unitecA";
    // public static final String CHANNEL_UNITECB = "unitecB";
    // public static final String CHANNEL_UNITECC = "unitecC";
    // public static final String CHANNEL_UNITECD = "unitecD";
}

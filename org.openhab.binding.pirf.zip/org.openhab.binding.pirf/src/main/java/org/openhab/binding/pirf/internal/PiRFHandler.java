/**
 * Copyright (c) 2010-2021 Contributors to the openHAB project
 *
 * See the NOTICE file(s) distributed with this work for additional
 * information.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0
 *
 * SPDX-License-Identifier: EPL-2.0
 */
package org.openhab.binding.pirf.internal;

import java.util.BitSet;

import org.eclipse.jdt.annotation.NonNullByDefault;
import org.openhab.binding.pirf.internal.rcswitch.Protocol;
import org.openhab.binding.pirf.internal.rcswitch.RCSwitch;
import org.openhab.core.config.core.Configuration;
import org.openhab.core.library.types.OnOffType;
import org.openhab.core.thing.Channel;
import org.openhab.core.thing.ChannelUID;
import org.openhab.core.thing.Thing;
import org.openhab.core.thing.ThingStatus;
import org.openhab.core.thing.ThingStatusDetail;
import org.openhab.core.thing.binding.BaseThingHandler;
import org.openhab.core.thing.type.ChannelTypeUID;
import org.openhab.core.types.Command;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.pi4j.io.gpio.Pin;
import com.pi4j.io.gpio.RaspiPin;

/**
 * The {@link PiRFHandler} is responsible for handling commands, which are
 * sent to one of the channels.
 *
 * @author Chasbrot - Initial contribution
 */
@NonNullByDefault
public class PiRFHandler extends BaseThingHandler {

    private final Logger logger = LoggerFactory.getLogger(PiRFHandler.class);

    private PiRFUnitec pu = new PiRFUnitec();

    // private @Nullable PiRFBindingConfiguration config;

    public PiRFHandler(Thing thing) {
        super(thing);
    }

    @Override
    public void handleCommand(ChannelUID channelUID, Command command) {
        Channel channel = getThing().getChannel(channelUID);
        if (channel == null) {
            return;
        }
        ChannelTypeUID cTUID = channel.getChannelTypeUID();
        if (cTUID == null) {
            return;
        }
        switch (cTUID.getId()) {
            case PiRFBindingConstants.CHANNEL_TYPE_SWITCH:
                if (command instanceof OnOffType) {
                    codeSendRC(channelUID, command);
                }
                break;
            case PiRFBindingConstants.CHANNEL_TYPE_GROUP:
                if (command instanceof OnOffType) {
                    codeSendGroup(channelUID, command);
                }
                break;
            case PiRFBindingConstants.CHANNEL_TYPE_UNITEC:
                if (command instanceof OnOffType) {
                    codeSendUnitec(channelUID, command);
                }
                break;
            default:
                logger.warn("PiRF Unknown Channel TypeID: {}", cTUID.getId());
        }
    }

    @Override
    public void initialize() {
        // config = getConfigAs(PiRFBindingConfiguration.class);
        updateStatus(ThingStatus.UNKNOWN);

        // Example for background initialization:
        scheduler.execute(() -> {

            // Check if operating system is compatible
            String os = System.getProperty("os.name");
            if (os == null) {
                updateStatus(ThingStatus.OFFLINE, ThingStatusDetail.CONFIGURATION_ERROR, "OS Detection failed");
                return;
            }
            os = os.toLowerCase();
            if (!(os.indexOf("nix") >= 0 || os.indexOf("nux") >= 0 || os.indexOf("aix") >= 0)) {
                // On Windows / not Linux
                logger.warn("PiRF not functional under Windows!");
            }
            // If everything is ok
            updateStatus(ThingStatus.ONLINE);
        });
    }

    private synchronized boolean codeSendRC(ChannelUID channel, Command com) {
        Channel c = getThing().getChannel(channel);
        if (c == null) {
            return false;
        }
        Configuration channelconfig = c.getConfiguration();
        Configuration thingconfig = getThing().getConfiguration();

        // Pin Address == Pin Number
        if (thingconfig.get("pin") == null) {
            updateStatus(ThingStatus.OFFLINE, ThingStatusDetail.CONFIGURATION_ERROR, "No GPIO Pin set");
            return false;
        }
        Pin pi = RaspiPin.getPinByAddress(Integer.parseInt(thingconfig.get("pin").toString()));

        // Define used protocol
        Protocol pr = null;
        if (thingconfig.get("protocol") == null) {
            updateStatus(ThingStatus.OFFLINE, ThingStatusDetail.CONFIGURATION_ERROR, "Unknown protocol set");
            return false;
        }
        switch (thingconfig.get("protocol").toString()) {
            case "1":
                pr = Protocol.PROTOCOL_01;
                break;
            case "2":
                pr = Protocol.PROTOCOL_02;
                break;
            case "3":
                pr = Protocol.PROTOCOL_03;
                break;
            case "4":
                pr = Protocol.PROTOCOL_04;
                break;
            case "5":
                pr = Protocol.PROTOCOL_05;
                break;
            case "6":
                pr = Protocol.PROTOCOL_06;
                break;
            case "7":
                pr = Protocol.PROTOCOL_07;
                break;
            default:
                logger.warn("PiRF: Unknown protocol");
                return false;
        }

        if (thingconfig.get("pulslength") != null) {
            String pl = thingconfig.get("pulslength").toString();
            pr = new Protocol(Integer.parseInt(pl), pr.getSyncBit(), pr.getZeroBit(), pr.getOneBit(),
                    pr.isInvertedSignal());
        }

        // Check on/off code
        String binary = "";
        if (com.toString().equals("ON")) {
            binary = Integer.toBinaryString(Integer.parseInt(channelconfig.get("oncode").toString()));
        } else {
            binary = Integer.toBinaryString(Integer.parseInt(channelconfig.get("offcode").toString()));
        }

        // Build 24 bit binary string
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < (24 - binary.length()); i++) {
            sb.append("0");
        }
        sb.append(binary);

        // Send code
        try {
            RCSwitch transmitter = new RCSwitch(pi, pr);
            transmitter.send(sb.toString());
        } catch (Exception ex) {
            logger.warn("PiRF RCSwitch: {}", ex.getMessage());
            updateStatus(ThingStatus.OFFLINE, ThingStatusDetail.CONFIGURATION_ERROR, "WiringPi error");
            return false;
        }

        return true;
    }

    private synchronized boolean codeSendGroup(ChannelUID channel, Command com) {
        Channel c = getThing().getChannel(channel);
        if (c == null) {
            return false;
        }
        Configuration channelconfig = c.getConfiguration();
        Configuration thingconfig = getThing().getConfiguration();

        // Pin Address == Pin Number
        if (thingconfig.get("pin") == null) {
            updateStatus(ThingStatus.OFFLINE, ThingStatusDetail.CONFIGURATION_ERROR, "No Pin set");
            return false;
        }
        Pin pi = RaspiPin.getPinByAddress(Integer.parseInt(thingconfig.get("pin").toString()));

        try {
            RCSwitch transmitter = new RCSwitch(pi);
            BitSet ga = RCSwitch.getSwitchGroupAddress(channelconfig.get("groupaddress").toString());
            if (com.toString().equals("ON")) {
                transmitter.switchOn(ga, Integer.parseInt(channelconfig.get("deviceaddress").toString()));
            } else {
                transmitter.switchOff(ga, Integer.parseInt(channelconfig.get("deviceaddress").toString()));
            }
        } catch (UnsatisfiedLinkError ila) {
            logger.warn("WiringPi not found");
            updateStatus(ThingStatus.OFFLINE, ThingStatusDetail.CONFIGURATION_ERROR, "WiringPi not found");
            return false;
        }

        return true;
    }

    private synchronized boolean codeSendUnitec(ChannelUID channel, Command com) {
        Channel c = getThing().getChannel(channel);
        if (c == null) {
            logger.warn("channelconfig null");
            return false;
        }
        Configuration channelconfig = c.getConfiguration();
        Configuration thingconfig = getThing().getConfiguration();

        if (pu.getTxPin() == -1) {
            // Pin Address == Pin Number
            if (thingconfig.get("pin") == null) {
                updateStatus(ThingStatus.OFFLINE, ThingStatusDetail.CONFIGURATION_ERROR, "No Pin set");
                return false;
            }
            try {
                if (pu.setTxPin(Integer.parseInt(thingconfig.get("pin").toString()))) {
                    updateStatus(ThingStatus.OFFLINE, ThingStatusDetail.COMMUNICATION_ERROR, "Cannot set TX Pin");
                    return false;
                }
            } catch (Exception ex) {
                updateStatus(ThingStatus.OFFLINE, ThingStatusDetail.CONFIGURATION_ERROR, "Wiring Pi error");
                return false;
            }
        }

        // Check control codes and parse to array
        String[] data;
        if (com.toString().equals("ON")) {
            if (channelconfig.get("uniteccodeson") == null) {
                updateStatus(ThingStatus.OFFLINE, ThingStatusDetail.CONFIGURATION_ERROR, "control codes on are null");
                return false;
            }
            data = channelconfig.get("uniteccodeson").toString().split(";");
        } else {
            if (channelconfig.get("uniteccodesoff") == null) {
                updateStatus(ThingStatus.OFFLINE, ThingStatusDetail.CONFIGURATION_ERROR, "control codes off are null");
                return false;
            }
            data = channelconfig.get("uniteccodesoff").toString().split(";");
        }

        if (data.length != 4) {
            updateStatus(ThingStatus.OFFLINE, ThingStatusDetail.CONFIGURATION_ERROR, "Number of codes not 4");
            return false;
        }
        long co[] = new long[PiRFUnitec.UNITEC_NUM_ROLLINGCODES];

        try {
            for (int i = 0; i < data.length; i++) {
                co[i] = Long.parseLong(data[i]);
            }
        } catch (NumberFormatException nfe) {
            updateStatus(ThingStatus.OFFLINE, ThingStatusDetail.CONFIGURATION_ERROR, "Cannot parse codes");
            return false;
        }

        // Set codes and send them
        try {
            pu.setBtnCodes(co);
            pu.switchUnitec();
        } catch (Exception ex) {
            // Catch wiring pi exceptions
            logger.warn("PiRF Unitec: {}", ex.getMessage());
            updateStatus(ThingStatus.OFFLINE, ThingStatusDetail.COMMUNICATION_ERROR, "Wiring Pi error");
            return false;
        }

        return true;
    }
}
